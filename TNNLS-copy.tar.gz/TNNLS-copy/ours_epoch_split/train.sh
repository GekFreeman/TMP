d1=`date +%Y_%m_%d_%H_%M_%S`
# /root/anaconda3/envs/isda/bin/python train_da.py 
/userhome/anaconda3/envs/pytorch/bin/python train_da.py --s1 webcam --s2 dslr --t amazon --seed 83 --mode 1 #> logs/${d1}.txt 2>&1 
