# tensorboard --logdir /root/workspace/zhangc/ISDA/save/resnet50_mini-imagenet/tensorboard
while ((1 == 1))
do
    sshpass -p 'Zc218705' scp -r save/resnet50_mini-imagenet/w-ml-47-webcam-dslrOutBN/events.out.tfevents.1639650300.c978a9c005e4b011ec08bb20f3128d160513-chengyl209-0 root@81.71.138.11:/root/workspace/tensorboard/
    sleep 5
done