# target_dir=../Reproduce/Office31/WDA/seed-47/
# cp -r ./configs  $target_dir
# cp -r ./models  $target_dir
# cp -r ./utils  $target_dir
# cp -r *.py $target_dir
# cp -r *.sh $target_dir
mkdir save && cd save
mkdir resnet50_mini-imagenet && cd ..
cp -r /userhome/chengyl/UDA/multi-source/ISDA/ISDA_V2/save/resnet50_mini-imagenet/w-ml-47-webcam-dslr-Rep ./save/resnet50_mini-imagenet/
cp -r /userhome/chengyl/UDA/multi-source/ISDA/ISDA_V2/save/resnet50_mini-imagenet/webcam_w-ml-47-webcam-dslr-Rep.pth ./save/resnet50_mini-imagenet/
cp -r /userhome/chengyl/UDA/multi-source/ISDA/ISDA_V2/save/resnet50_mini-imagenet/w-ml-47-webcam-dslr-Rep.pth ./save/resnet50_mini-imagenet/