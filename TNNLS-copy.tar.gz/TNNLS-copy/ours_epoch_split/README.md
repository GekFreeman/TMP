目的：
1.方法与动机的对应：

实验步骤：
1.使用源域W的cls+mmd得到初始模型；
2.对比：
    A.(I/O) + finetune(O);
    B.(I+O) + finetune(O);
    C.(I/O) + finetune(I+O);
    D.(I+O) + finetune(I+O);