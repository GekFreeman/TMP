d1=`date +%Y_%m_%d_%H_%M_%S`
# /root/anaconda3/envs/isda/bin/python train_da.py 
/userhome/anaconda3/envs/mfsan/bin/python train_da.py --s1 webcam --s2 dslr --t amazon --seed 83 --mode 1 > logs/${d1}.txt 2>&1

# d1=`date +%Y_%m_%d_%H_%M_%S`
# /userhome/anaconda/envs/pytorch/bin/python train_da.py --s1 p --s2 i --t c --seed 83 --mode 1 > logs/${d1}.txt 2>&1

# d1=`date +%Y_%m_%d_%H_%M_%S`
# /userhome/anaconda/envs/pytorch/bin/python train_da.py --s1 c --s2 p --t i --seed 83 --mode 1 > logs/${d1}.txt 2>&1

# d1=`date +%Y_%m_%d_%H_%M_%S`
# /userhome/anaconda/envs/pytorch/bin/python train_da.py --s1 c --s2 i --t p --seed 83 --mode 1 > logs/${d1}.txt 2>&1

# d1=`date +%Y_%m_%d_%H_%M_%S`
# /userhome/anaconda/envs/pytorch/bin/python train_da.py --s1 i --s2 c --t p --seed 83 --mode 1 > logs/${d1}.txt 2>&1

# d1=`date +%Y_%m_%d_%H_%M_%S`
# /userhome/anaconda/envs/pytorch/bin/python train_da.py --s1 i --s2 p --t c --seed 83 --mode 1 > logs/${d1}.txt 2>&1
