# Copyright 2022-present, Lorenzo Bonicelli, Pietro Buzzega, Matteo Boschini, Angelo Porrello, Simone Calderara.
# All rights reserved.
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

from torchvision.datasets import MNIST
import torchvision.transforms as transforms
from datasets.transforms.permutation import Permutation
from torch.utils.data import DataLoader
from backbone.MNISTMLP import MNISTMLP
import torch.nn.functional as F
from utils.conf import base_path
from PIL import Image
from datasets.utils.validation import get_train_val
from typing import Tuple
from datasets.utils.continual_dataset import ContinualDataset
from augmentations import PseSimSiamTransform
from datasets.transforms.rotation import Rotation

imagenet_norm = [[0.4914, 0.4822, 0.4465],[0.2470, 0.2435, 0.2615]]
def store_mnist_loaders(setting, normalize=imagenet_norm, num_workers=32):
    rotat = Rotation()
    train_transforms = transforms.Compose([rotat,
                       PseSimSiamTransform(image_size=28)])
    test_transforms = transforms.Compose([
                rotat,
#                 transforms.Resize((224, 224)),
                transforms.Grayscale(3),
                transforms.ToTensor(),
                transforms.Normalize((0.1307,0.1307,0.1307), (0.3081,0.3081,0.3081)),
            ])
    
    train_dataset = MyMNIST(base_path() + 'MNIST',
                            train=True, download=True, transform=train_transforms)
    
    memory_dataset = MyMNIST(base_path() + 'MNIST',
                            train=True, download=True, transform=test_transforms)
    
    if setting.args.validation:
        train_dataset, test_dataset = get_train_val(train_dataset,
                                                    train_transforms, setting.NAME)
    else:
        test_dataset = MNIST(base_path() + 'MNIST',
                             train=False, download=True, transform=test_transforms)

    train_loader = DataLoader(train_dataset,
                              batch_size=setting.args.train.batch_size, shuffle=True, num_workers=num_workers)
    memory_loader = DataLoader(memory_dataset,
                              batch_size=setting.args.train.batch_size, shuffle=False, num_workers=num_workers) # by z.c.
    test_loader = DataLoader(test_dataset,
                             batch_size=setting.args.train.batch_size, shuffle=False, num_workers=num_workers)
    setting.test_loaders.append(test_loader)
    setting.train_loaders.append(train_loader)
    setting.memory_loaders.append(memory_loader)
    setting.train_loader = train_loader

    return train_loader, memory_loader, test_loader


class MyMNIST(MNIST):
    """
    Overrides the MNIST dataset to change the getitem function.
    """
    def __init__(self, root, train=True, transform=None,
                 target_transform=None, download=False) -> None:
        super(MyMNIST, self).__init__(root, train, transform,
                                      target_transform, download)
        self.train_loader = None
        self.test_loaders = []
        self.memory_loaders = []
        self.train_loaders = []

    def __getitem__(self, index: int) -> Tuple[type(Image), int, type(Image)]:
        """
        Gets the requested element from the dataset.
        :param index: index of the element to be returned
        :returns: tuple: (image, target) where target is index of the target class.
        """
        img, target = self.data[index], int(self.targets[index])

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = Image.fromarray(img.numpy(), mode='L')

        if self.transform is not None:
            img = self.transform(img)

        if self.target_transform is not None:
            target = self.target_transform(target)

        return img, target


class PermutedMNIST(ContinualDataset):

    NAME = 'perm-mnist'
    SETTING = 'domain-il'
    N_CLASSES_PER_TASK = 10
    N_TASKS = 20

    def get_data_loaders(self):
        transform = transforms.Compose((transforms.ToTensor(), Permutation()))
        train, test = store_mnist_loaders(transform, self)
        return train, test
        
    @staticmethod
    def get_backbone():
        return MNISTMLP(28 * 28, PermutedMNIST.N_CLASSES_PER_TASK)

    @staticmethod
    def get_transform():
        return None

    @staticmethod
    def get_normalization_transform():
        return None

    @staticmethod
    def get_denormalization_transform():
        return None

    @staticmethod
    def get_loss():
        return F.cross_entropy

    @staticmethod
    def get_scheduler(model, args):
        return None