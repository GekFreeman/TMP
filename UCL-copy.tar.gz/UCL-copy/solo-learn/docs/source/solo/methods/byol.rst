BYOL
====


.. automethod:: solo.methods.byol.BYOL.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.byol.BYOL.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.byol.BYOL.learnable_params
   :noindex:

momentum_pairs
~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.byol.BYOL.momentum_pairs
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.byol.BYOL.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.byol.BYOL.training_step
   :noindex:
