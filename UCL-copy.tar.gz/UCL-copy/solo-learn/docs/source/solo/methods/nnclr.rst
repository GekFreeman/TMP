NNCLR
=====

.. automethod:: solo.methods.nnclr.NNCLR.__init__
   :noindex:


add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnclr.NNCLR.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.nnclr.NNCLR.learnable_params
   :noindex:

dequeue_and_enqueue
~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnclr.NNCLR.dequeue_and_enqueue
   :noindex:

find_nn
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnclr.NNCLR.find_nn
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.nnclr.NNCLR.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.nnclr.NNCLR.training_step
   :noindex:
