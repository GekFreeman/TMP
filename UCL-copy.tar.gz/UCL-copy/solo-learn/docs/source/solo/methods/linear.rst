LinearModel
===========


.. automethod:: solo.methods.linear.LinearModel.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.add_model_specific_args
   :noindex:

configure_optimizers
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.configure_optimizers
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.forward
   :noindex:

shared_step
~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.shared_step
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.training_step
   :noindex:

validation_step
~~~~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.validation_step
   :noindex:

validation_epoch_end
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.linear.LinearModel.validation_epoch_end
   :noindex:
