NNBYOL
======

.. automethod:: solo.methods.nnbyol.NNBYOL.__init__
   :noindex:


add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnbyol.NNBYOL.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.nnbyol.NNBYOL.learnable_params
   :noindex:

dequeue_and_enqueue
~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnbyol.NNBYOL.dequeue_and_enqueue
   :noindex:

find_nn
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnbyol.NNBYOL.find_nn
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.nnbyol.NNBYOL.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.nnbyol.NNBYOL.training_step
   :noindex:
