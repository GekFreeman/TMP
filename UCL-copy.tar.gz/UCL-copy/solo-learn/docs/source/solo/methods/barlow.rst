Barlow Twins
============


.. automethod:: solo.methods.barlow_twins.BarlowTwins.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.barlow_twins.BarlowTwins.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.barlow_twins.BarlowTwins.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.barlow_twins.BarlowTwins.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.barlow_twins.BarlowTwins.training_step
   :noindex:
