DALI
====

DALI.PretrainABC
----------------
.. autoclass:: solo.methods.dali.PretrainABC


DALI.ClassificationABC
----------------------
.. autoclass:: solo.methods.dali.ClassificationABC
