SimCLR
============


.. automethod:: solo.methods.simclr.SimCLR.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.simclr.SimCLR.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.simclr.SimCLR.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.simclr.SimCLR.forward
   :noindex:

gen_extra_positives_gt
~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.simclr.SimCLR.gen_extra_positives_gt
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.simclr.SimCLR.training_step
   :noindex:
