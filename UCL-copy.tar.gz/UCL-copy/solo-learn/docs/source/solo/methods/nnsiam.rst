NNSiam
======

.. automethod:: solo.methods.nnsiam.NNSiam.__init__
   :noindex:


add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnsiam.NNSiam.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.nnsiam.NNSiam.learnable_params
   :noindex:

dequeue_and_enqueue
~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnsiam.NNSiam.dequeue_and_enqueue
   :noindex:

find_nn
~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.nnsiam.NNSiam.find_nn
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.nnsiam.NNSiam.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.nnsiam.NNSiam.training_step
   :noindex:
