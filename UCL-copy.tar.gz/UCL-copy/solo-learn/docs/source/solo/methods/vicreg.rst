VICReg
======


.. automethod:: solo.methods.vicreg.VICReg.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.vicreg.VICReg.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.vicreg.VICReg.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.vicreg.VICReg.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.vicreg.VICReg.training_step
   :noindex:
