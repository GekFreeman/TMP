W-MSE
=====


.. automethod:: solo.methods.wmse.WMSE.__init__
   :noindex:

add_model_specific_args
~~~~~~~~~~~~~~~~~~~~~~~
.. automethod:: solo.methods.wmse.WMSE.add_model_specific_args
   :noindex:

learnable_params
~~~~~~~~~~~~~~~~
.. autoattribute:: solo.methods.wmse.WMSE.learnable_params
   :noindex:

forward
~~~~~~~
.. automethod:: solo.methods.wmse.WMSE.forward
   :noindex:

training_step
~~~~~~~~~~~~~
.. automethod:: solo.methods.wmse.WMSE.training_step
   :noindex:
