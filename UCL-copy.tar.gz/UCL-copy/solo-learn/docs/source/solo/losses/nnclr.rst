NNCLR
-----

.. autofunction:: solo.losses.nnclr.nnclr_loss_func
   :noindex: