MoCo-V2
-------

.. autofunction:: solo.losses.moco.moco_loss_func
   :noindex: