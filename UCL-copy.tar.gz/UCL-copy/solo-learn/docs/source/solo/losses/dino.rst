DINO
----

.. automethod:: solo.losses.dino.DINOLoss.__init__
   :noindex:
