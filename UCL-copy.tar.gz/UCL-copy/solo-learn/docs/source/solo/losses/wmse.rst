W-MSE
-----

.. autofunction:: solo.losses.wmse.wmse_loss_func
   :noindex:
