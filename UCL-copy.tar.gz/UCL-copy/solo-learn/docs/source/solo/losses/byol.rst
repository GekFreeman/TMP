BYOL
----

.. autofunction:: solo.losses.byol.byol_loss_func
   :noindex:
