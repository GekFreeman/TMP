SimCLR
------

.. autofunction:: solo.losses.simclr.simclr_loss_func
   :noindex:

.. autofunction:: solo.losses.simclr.manual_simclr_loss_func
